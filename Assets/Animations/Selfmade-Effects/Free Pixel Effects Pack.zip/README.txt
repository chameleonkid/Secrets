This is a public domain asset, you can use it for both personal and comercial purposes. 
No credit required but feel free to show us where you used it on @DavitMasia and @CodeManuPro at twitter. :)

Frame size is 100x100px. 

All these effects were created with Pixel FX Designer: https://codemanu.itch.io/particle-fx-designer